import { Component, OnInit } from '@angular/core';
import { Product } from '../model/item';
import { Router } from '@angular/router';
import { ApiService } from '../service/api.service';
import { FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-additem',
  templateUrl: './additem.component.html',
  styleUrls: ['./additem.component.css']
})
export class AdditemComponent implements OnInit {

  
product : Product =new Product();


  constructor(private formBuilder: FormBuilder,private pService:ApiService,private route:Router) { }

  ngOnInit(): void {
  }
  


}

