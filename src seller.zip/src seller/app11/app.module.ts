import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PqrComponent } from './pqr/pqr.component';
import { PavanComponent } from './pavan/pavan.component';

@NgModule({
  declarations: [
    AppComponent,
    PqrComponent,
    PavanComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
