import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-additem',
  templateUrl: './additem.component.html',
  styleUrls: ['./additem.component.css']
})
export class AdditemComponent implements OnInit {


product : Product=new Product();
submitted=false;

  constructor(private pService:ProductService,private route:Router) { }

  ngOnInit(): void {
  }
  display(){

  this.route.navigate(['displayitem']);
}
  newProduct(): void{

    this.submitted =false;
    this.product = new Product();

  }
 save(){
   
  this.pService.addItem(this.product)
  .subscribe(data =>console.log(data), error => console.log(error));
  this.product = new Product();
alert("item added successfully!!");
 }

 onSubmit(){
 
  this.submitted=true;
  this.save();


 }


}
