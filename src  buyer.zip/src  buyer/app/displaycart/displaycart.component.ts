import { Component, OnInit } from '@angular/core';
import { Cart, ViewCart } from '../cart';
import { ProductService } from '../product.service';
import { Transcation } from '../transcation';
import { Router } from '@angular/router';
import { Token } from '@angular/compiler/src/ml_parser/lexer';

@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {
  // disCart:Cart=new Cart();
    disCart:Cart[];
  viewcart:ViewCart=new ViewCart();
  transcation:Transcation=new Transcation();
  cost:number;
  subtotal:number;
    success:string;
  //cart: any;
  i:any;
  constructor(private displaycart:ProductService,private router:Router) { }
  ngOnInit(): void {
    this.reloadcartItems();
    console.log(this.disCart);
    if(!window.localStorage.getItem('Token')) {
      //this.router.navigate(['disitem']);
      return;
    }
    }
  reloadcartItems(){
    this.displaycart.displayCartItems().subscribe( disCart => 
      {console.log("markk"+JSON.stringify(disCart)); this.disCart=disCart;});
  }
  decrement(cartview:ViewCart){
    this.cost=cartview.price;
    console.log(cartview.price);
    if(cartview.quantity!=1){
    cartview.quantity-=1;
       cartview.totalprice= cartview.quantity * this.cost;
       //this.subtotal-=this.viewcart.totalpr
    console.log(cartview.quantity,cartview.cartItemId);
        this.displaycart.updateCartItems(cartview).subscribe(newview => this.viewcart=newview);
    }
   }
  increment(cartview:ViewCart){
    this.cost=cartview.price;
     cartview.quantity+=1
       if(cartview.quantity!=1){
    cartview.totalprice= cartview.quantity * this.cost;
    this.subtotal+=this.cost*cartview.quantity;
    console.log(cartview);
    console.log("Quantity"+cartview.quantity+"\nCartID:"+cartview.cartItemId);
    this.displaycart.updateCartItems(cartview).subscribe(newview => this.viewcart=newview);
 }
  }

  DeleteItem(i){

    console.log("method invoked");
    console.log(i);
    this.displaycart.DeleteCartItem(i).subscribe(

      () =>{console.log("deleted Item"); this.reloadcartItems();}, (error) => console.log(error)

    );
  }
  DeleteAll(){
    this.displaycart.emptycart().subscribe(

    () =>console.log("Delete All Items"),
    (error) =>console.log(error)
          );
  }
 Checkout(transcation:Transcation){
  console.log("entering the method"+transcation);
     this.displaycart.CheckoutCart(transcation).subscribe(
  () =>{console.log("success"); this.reloadcartItems()},
   (error) => console.log(error));
   window.alert("checkout done successfully!");
   this.router.navigate(['trancation']);
 }


}
