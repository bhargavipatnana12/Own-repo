import { Component, OnInit, Input } from '@angular/core';
@Component({
  selector: 'app-sellerdetails',
  templateUrl: './sellerdetails.component.html',
  styleUrls: ['./sellerdetails.component.css']
})
export class SellerdetailsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
